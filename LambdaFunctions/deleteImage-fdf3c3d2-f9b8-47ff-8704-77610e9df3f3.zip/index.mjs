import {
  S3Client,
  HeadObjectCommand,
  DeleteObjectCommand,
} from "@aws-sdk/client-s3";

const s3 = new S3Client({});
const BUCKET_NAME = process.env.UPLOAD_BUCKET;

export const handler = async (event) => {
  try {
    const body = event?.body ? JSON.parse(event.body) : {};
    const key = body.key;
    const sha256 = body.sha256;

    if (!key || !sha256) {
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({ error: "key and sha256 are required." }),
      };
    }

    if (!key.startsWith("processed/")) {
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({ error: "Only processed/ objects may be deleted." }),
      };
    }

    const head = await s3.send(new HeadObjectCommand({
      Bucket: BUCKET_NAME,
      Key: key,
    }));

    const storedSha256 = head.Metadata?.sha256 ?? "";

    if (!storedSha256) {
      return {
        statusCode: 409,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({ error: "Object has no stored sha256 metadata." }),
      };
    }

    if (storedSha256.toLowerCase() !== sha256.toLowerCase()) {
      return {
        statusCode: 409,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({
          error: "Checksum mismatch. Object was not deleted.",
          expected: storedSha256,
        }),
      };
    }

    await s3.send(new DeleteObjectCommand({
      Bucket: BUCKET_NAME,
      Key: key,
    }));

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        success: true,
        deletedKey: key,
      }),
    };
  } catch (error) {
    console.error("deleteProcessedImage error:", error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        error: "Failed to delete image.",
        details: error.message,
      }),
    };
  }
};