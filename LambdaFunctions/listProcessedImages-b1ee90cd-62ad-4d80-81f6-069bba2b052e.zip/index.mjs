import {
  S3Client,
  ListObjectsV2Command,
  HeadObjectCommand,
  GetObjectCommand,
} from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

const s3 = new S3Client({});
const BUCKET_NAME = process.env.UPLOAD_BUCKET;
const PREFIX = "processed/";

export const handler = async () => {
  try {
    const listResponse = await s3.send(new ListObjectsV2Command({
      Bucket: BUCKET_NAME,
      Prefix: PREFIX,
      MaxKeys: 100,
    }));

    const contents = (listResponse.Contents ?? [])
      .filter(x => x.Key && !x.Key.endsWith("/"))
      .sort((a, b) => new Date(b.LastModified ?? 0) - new Date(a.LastModified ?? 0));

    const items = await Promise.all(contents.map(async (obj) => {
      const key = obj.Key;

      const head = await s3.send(new HeadObjectCommand({
        Bucket: BUCKET_NAME,
        Key: key,
      }));

      const downloadUrl = await getSignedUrl(
        s3,
        new GetObjectCommand({
          Bucket: BUCKET_NAME,
          Key: key,
        }),
        { expiresIn: 3600 }
      );

      return {
        key,
        downloadUrl,
        sha256: head.Metadata?.sha256 ?? "",
        lastModified: obj.LastModified,
        size: obj.Size,
      };
    }));

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ items }),
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({ error: error.message }),
    };
  }
};