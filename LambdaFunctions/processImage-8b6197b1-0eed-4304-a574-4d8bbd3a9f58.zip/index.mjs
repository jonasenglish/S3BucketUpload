import {
  S3Client,
  GetObjectCommand,
  PutObjectCommand,
  DeleteObjectCommand,
  HeadObjectCommand,
} from "@aws-sdk/client-s3";
import crypto from "node:crypto";

const s3 = new S3Client({});

async function streamToBuffer(stream) {
  const chunks = [];
  for await (const chunk of stream) {
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

export const handler = async (event) => {
  console.log("Received event:", JSON.stringify(event, null, 2));

  const results = [];

  for (const record of event.Records ?? []) {
    try {
      const bucket = record.s3.bucket.name;
      const key = decodeURIComponent(record.s3.object.key.replace(/\+/g, " "));

      if (key.startsWith("processed/")) {
        results.push({ key, status: "skipped", reason: "Already processed prefix" });
        continue;
      }

      const head = await s3.send(new HeadObjectCommand({
        Bucket: bucket,
        Key: key,
      }));

      const contentType = head.ContentType || "";
      if (!contentType.startsWith("image/")) {
        results.push({ key, status: "skipped", reason: `Not an image: ${contentType}` });
        continue;
      }

      const getResp = await s3.send(new GetObjectCommand({
        Bucket: bucket,
        Key: key,
      }));

      const bodyBuffer = await streamToBuffer(getResp.Body);

      const sha256Hex = crypto.createHash("sha256").update(bodyBuffer).digest("hex");

      const processedKey = key.startsWith("incoming/")
        ? key.replace(/^incoming\//, "processed/")
        : `processed/${key}`;

      await s3.send(new PutObjectCommand({
        Bucket: bucket,
        Key: processedKey,
        Body: bodyBuffer,
        ContentType: contentType,
        Metadata: {
          sha256: sha256Hex,
          originalkey: key,
        },
      }));

      await s3.send(new DeleteObjectCommand({
        Bucket: bucket,
        Key: key,
      }));

      results.push({
        key,
        processedKey,
        status: "processed_and_deleted_source",
        sha256: sha256Hex,
      });
    } catch (error) {
      console.error("Error processing record:", error);
      results.push({
        key: record?.s3?.object?.key ?? "unknown",
        status: "error",
        error: error.message,
      });
    }
  }

  return {
    statusCode: 200,
    body: JSON.stringify({ results }),
  };
};