import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import crypto from "node:crypto";

const s3 = new S3Client({});

// Set this in Lambda > Configuration > Environment variables
const BUCKET_NAME = process.env.UPLOAD_BUCKET;

// Allowed image types for Unity uploads
const ALLOWED_CONTENT_TYPES = new Set([
  "image/png",
  "image/jpeg",
  "image/webp",
  "image/gif"
]);

// Optional safety check by extension
const ALLOWED_EXTENSIONS = new Set([
  ".png",
  ".jpg",
  ".jpeg",
  ".webp",
  ".gif"
]);

function getExtension(fileName) {
  const dotIndex = fileName.lastIndexOf(".");
  if (dotIndex === -1) return "";
  return fileName.slice(dotIndex).toLowerCase();
}

function sanitizeBaseName(fileName) {
  // Remove directory paths if someone sends them
  const lastSlash = Math.max(fileName.lastIndexOf("/"), fileName.lastIndexOf("\\"));
  const justName = lastSlash >= 0 ? fileName.slice(lastSlash + 1) : fileName;

  // Keep letters, numbers, dash, underscore, dot
  return justName.replace(/[^a-zA-Z0-9._-]/g, "_");
}

export const handler = async (event) => {
  try {
    console.log("Incoming event:", JSON.stringify(event, null, 2));

    if (!BUCKET_NAME) {
      return {
        statusCode: 500,
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          error: "Missing UPLOAD_BUCKET environment variable."
        })
      };
    }

    const body = event?.body ? JSON.parse(event.body) : {};

    const fileName = body.fileName;
    const contentType = body.contentType;

    if (!fileName || !contentType) {
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          error: "fileName and contentType are required."
        })
      };
    }

    if (!ALLOWED_CONTENT_TYPES.has(contentType)) {
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          error: `Unsupported contentType: ${contentType}`
        })
      };
    }

    const safeName = sanitizeBaseName(fileName);
    const extension = getExtension(safeName);

    if (!ALLOWED_EXTENSIONS.has(extension)) {
      return {
        statusCode: 400,
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          error: `Unsupported file extension: ${extension || "(none)"}`
        })
      };
    }

    // Generate a unique key under incoming/
    const id = crypto.randomUUID();
    const objectKey = `incoming/${id}${extension}`;

    const command = new PutObjectCommand({
      Bucket: BUCKET_NAME,
      Key: objectKey,
      ContentType: contentType
    });

    // 300 seconds = 5 minutes
    const uploadUrl = await getSignedUrl(s3, command, { expiresIn: 300 });

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        // Helpful if API Gateway CORS isn't fully configured yet
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        uploadUrl,
        bucket: BUCKET_NAME,
        objectKey,
        contentType,
        expiresIn: 300
      })
    };
  } catch (error) {
    console.error("Presign error:", error);

    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        error: "Failed to create presigned URL.",
        details: error.message
      })
    };
  }
};